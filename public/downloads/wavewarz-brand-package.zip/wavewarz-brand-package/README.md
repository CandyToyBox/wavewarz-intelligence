# WaveWarZ — Official Brand Guide Edition Package

**Prepared for:** Argon / wavewarz.info Engineering  
**Date:** October 2026  
**Primary Entrypoint:** `index.html` (or `wavewarz_brand_guide_edition.html`)

---

## 1. Quick Start

All files in this package are 100% self-contained and require no compilation, bundler, or build step:

- Open `index.html` directly in any browser, or run a local server:
  ```bash
  python3 -m http.server 8080
  # visit http://localhost:8080/
  ```

---

## 2. Key Highlights in this Release

1. **Official Brand Color Guide Palette:**
   - **Primary Green:** `#95FE7C` (RGB: `149, 254, 124`)
   - **Primary Blue:** `#7EC1FB` (RGB: `126, 193, 251`)
   - **Guide Deep Blue:** `#106EFD` (RGB: `16, 110, 253`)
   - **Secondary Orange:** `#ff801d` (RGB: `255, 128, 29`)
   - **Secondary Lilac:** `#e171ea` (RGB: `225, 113, 234`)
   - **Ice Tint:** `#D8EBFC`
   - **Neutral Gray:** `#909090`
   - **Deep Canvas:** `#000000` (Pure Black) & `#070A10`

2. **16-Shard Fractal Logo Entrance:**
   - Slices the WaveWarZ logo into 16 interlocking crystalline shards that converge from 3D space, snap into place, and trigger a neon weld shockwave ring before entering an idle float.
   - Interactive **"✨ REPLAY FRACTAL"** button in the navbar to re-trigger the sequence anytime.

3. **Revamped Quick Battlez Deck:**
   - **Opposite Tilted Artist Cards:** Challenger A tilts left (`-2.6deg`), Challenger B tilts right (`+2.6deg`), leveling out on hover or audio playback.
   - **Docked 9-Segment Equalizers:** Real-time animated audio visualizer strips nested inside each artist card.
   - **Circular Ring Timer & Split Bar:** Center dial timer (`05:50`) with live countdown and `#7EC1FB` vs `#95FE7C` split bar.
   - **Web Audio Synth:** Audition tracks for Challenger A & B with real-time bassline synthesis.

4. **3D Mascot & Telemetry:**
   - Interactive 3D **DJ Wavy** mascot via Google `<model-viewer>` (`djwavy.glb`).
   - Lazy-loaded telemetry hubs for global analytics, artist profiles, and Lu.ma battle calendar.

---

## 3. Included Files

- `index.html` / `wavewarz_brand_guide_edition.html` — The primary release
- `wavewarz_fractal_tilted.html` — Standalone fractal edition
- `wavewarz_opening_choreography.html` — Choreographed opening sequence
- `wavewarz_argon_arena.html` — Quick battles arena edition
- `LUI.png` & `Geek cutout new.png` — High-res transparent fighter cutouts
- `ChatGPT Image Oct 13, 2026, 07_12_16 PM.png` — High-res Chrome logo & dynamic square favicon source
- `djwavy.glb` — Optimized 3D model
- `Images/` — Additional brand cutouts and artwork
