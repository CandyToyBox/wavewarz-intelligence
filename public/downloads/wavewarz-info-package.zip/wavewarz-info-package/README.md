# WaveWarZ — Landing Page & Web Prototype Package

**Prepared for:** Argon / wavewarz.info Team  
**Date:** October 2026  
**Primary Entrypoint:** `index.html` (or `prototype_v39.html`)

---

## 1. Quick Start

All files in this package are self-contained with no mandatory build or bundler pipeline required:

- Open `index.html` directly in any modern browser, or serve locally with any static web server:
  ```bash
  python3 -m http.server 8080
  # then visit http://localhost:8080/
  ```

---

## 2. What's Included in This Package

1. **`index.html` / `prototype_v39.html`**
   - The latest flagship implementation of the WaveWarZ landing page and web application prototype.
   - **Hero Stage & Liquid Motion:** Tightened cyber-luxurious framing with sound/water harmonic canvas, liquid word & character hover physics, and bidirectional fluid scroll choreographies.
   - **Interactive Sections:**
     - **Hero Fold:** Tagline typography lockup, audio-reactive canvas, live call-to-actions.
     - **DJ Wavy 3D Section:** Integrated `<model-viewer>` running `djwavy.glb`.
     - **Arena & Live Battles:** Live stage preview, artist matchup cards, and trading data visualization.
     - **How It Works & Settlement Breakdown:** Clear breakdown of live battle economics and on-chain settlement flows.

2. **3D Assets & Models**
   - `djwavy.glb` / `DJ WAVY compressed_compressed.glb`: Optimized 3D model asset for DJ Wavy.

3. **Graphics & Branding Assets**
   - `WAVEWARZ Logo.png`, `Wave Warz Logo colored.png`, `wavewarz-logo-cutout.png`, `wavewarz-logo-trimmed.png`, `wavewarz-logo-white-cutout.png`
   - `favicon-transparent.png`, `WaveWarz favicon colored.png`
   - `hero-character-clean.png`, `hero-character.png`, `hero-character.jpg`, `hero-character-original.png`
   - `Images/` subdirectory containing source graphic cutouts and official brand assets.

4. **Component Code & Specs**
   - `components/` — Modular React/Tailwind TSX references (`hero-section.tsx`, `dj-wavy-section.tsx`, `brand-intro-hero.tsx`, etc.).
   - `walkthrough.md` — Detailed engineering changelog and design rationale for the liquid typography, layout adjustments, and UI physics.
   - `task.md` — Checklist and feature matrix.

---

## 3. Technology & Dependencies

- **Typography:** Orbitron (display headings), Outfit (body copy), Inter (UI), JetBrains Mono (data/numbers) via Google Fonts.
- **3D Viewer:** Google `<model-viewer>` (CDN script tag included in head).
- **Styling:** Curated WaveWarZ dark cyber palette:
  - `--void: #050811;`
  - `--bg: #090e1c;`
  - `--card: rgba(12, 19, 34, 0.72);`
  - `--green: #95fe7c;` (Team B / Win)
  - `--blue: #7ec1fb;` (Team A)
  - `--cyan: #38bdf8;`
  - `--red: #ff453a;` (Sell)
