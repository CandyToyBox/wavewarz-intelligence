"use client";
import React from "react";
import { GradientWave, WAVEWARZ_GRADIENT_PALETTE } from "@/components/ui/gradient-wave";
import { FluidMouseRipple } from "@/components/ui/fluid-mouse-ripple";

export function BrandIntroHero() {
  return (
    <section className="relative w-full overflow-hidden bg-radial from-[#7ec1fb]/[0.06] to-transparent pt-20 pb-16 text-center">
      {/* WebGL Gradient Wave & Fluid Mouse Ripple Background */}
      <GradientWave
        colors={WAVEWARZ_GRADIENT_PALETTE}
        noiseSpeed={0.000008}
        noiseFrequency={[0.00012, 0.00035]}
        deform={{ incline: 0.45, noiseAmp: 260, noiseFlow: 4.2 }}
      />
      <FluidMouseRipple />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
        {/* Category Pill */}
        <div className="inline-flex items-center gap-2 font-mono text-xs sm:text-sm font-bold tracking-widest text-[#95fe7c] bg-[#95fe7c]/[0.08] border border-[#95fe7c]/35 px-5 py-2 rounded-full mb-8 backdrop-blur-md shadow-[0_0_25px_rgba(149,254,124,0.15)]">
          <span className="w-2 h-2 rounded-full bg-[#95fe7c] shadow-[0_0_8px_#95fe7c]" />
          MUSIC BATTLES MEET PREDICTION MARKETS
        </div>

        {/* Floating Brand Logo */}
        <img
          src="/logo-brand-colored.png"
          alt="WaveWarZ"
          className="w-full max-w-[360px] h-auto mb-8 drop-shadow-[0_0_35px_rgba(149,254,124,0.3)] animate-float"
        />

        {/* Headline */}
        <h1 className="font-disp font-black text-4xl sm:text-6xl lg:text-7xl text-white uppercase tracking-tight leading-[1.05] mb-6">
          Hear it first. Back it live.<br />
          <span className="bg-gradient-to-r from-[#95fe7c] via-[#5fdf49] to-[#7ec1fb] bg-clip-text text-transparent drop-shadow-[0_0_25px_rgba(149,254,124,0.35)]">
            Get paid when you're right.
          </span>
        </h1>

        {/* Brand Explanatory Subtext */}
        <p className="text-base sm:text-xl text-[#daecfd]/90 max-w-2xl leading-relaxed mb-10 font-normal">
          WaveWarZ turns music discovery into a high-stakes, onchain arena on Solana. Two artists go head-to-head in real-time battles while fans trade the wave and back their taste. Every single trade pays the artist instantly.
        </p>

        {/* Direct Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <a
            href="#arenaSection"
            className="inline-flex items-center justify-center font-semibold text-sm uppercase tracking-wider px-8 py-4 rounded-xl bg-gradient-to-br from-[#95fe7c] to-[#5fdf49] text-[#060913] shadow-[0_0_24px_rgba(149,254,124,0.3)] hover:shadow-[0_0_36px_rgba(149,254,124,0.5)] hover:-translate-y-0.5 transition-all duration-200"
          >
            Enter Live Battle
          </a>
          <a
            href="#howItWorks"
            className="inline-flex items-center justify-center font-semibold text-sm uppercase tracking-wider px-8 py-4 rounded-xl bg-[#7ec1fb]/[0.06] text-[#7ec1fb] border border-[#7ec1fb]/30 backdrop-blur-md hover:bg-[#7ec1fb]/15 hover:border-[#7ec1fb]/60 hover:-translate-y-0.5 transition-all duration-200"
          >
            How It Works
          </a>
          <a
            href="#djWavy"
            className="inline-flex items-center justify-center font-semibold text-sm uppercase tracking-wider px-8 py-4 rounded-xl bg-[#95fe7c]/[0.06] text-[#95fe7c] border border-[#95fe7c]/35 backdrop-blur-md hover:bg-[#95fe7c]/15 hover:border-[#95fe7c]/60 hover:-translate-y-0.5 transition-all duration-200"
          >
            Get Judged by DJ Wavy
          </a>
        </div>
      </div>
    </section>
  );
}
