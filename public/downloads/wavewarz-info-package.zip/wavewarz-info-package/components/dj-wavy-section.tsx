"use client";
import React, { useEffect, useRef } from "react";

export function DjWavySection() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Dynamically load Google model-viewer script if not present
    if (!customElements.get("model-viewer")) {
      const script = document.createElement("script");
      script.type = "module";
      script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js";
      document.head.appendChild(script);
    }
  }, []);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16" aria-label="DJ Wavy AI Judge">
      <div className="relative rounded-3xl overflow-hidden bg-[#0a0f1c]/70 backdrop-blur-2xl border border-[#7ec1fb]/20 shadow-[0_40px_100px_rgba(0,0,0,0.6)] grid grid-cols-1 lg:grid-cols-2 items-center">
        {/* Left Copy & CTA */}
        <div className="p-8 sm:p-12 lg:p-16 flex flex-col items-start">
          <div className="inline-flex items-center gap-2 font-mono text-xs font-bold tracking-widest text-[#7ec1fb] uppercase mb-4">
            <span className="w-2 h-2 rounded-full bg-[#7ec1fb] animate-ping" />
            RESIDENT AI JUDGE
          </div>

          <h2 className="font-disp font-extrabold text-4xl sm:text-5xl text-white uppercase leading-tight mb-6">
            Meet<br />
            <span className="text-[#95fe7c]">DJ Wavy</span>
          </h2>

          <p className="text-base sm:text-lg text-[#8b97ab] leading-relaxed mb-8 max-w-lg">
            The official AI Judge of WaveWarZ. For <b className="text-white">0.015 SOL</b>, put YOUR song head-to-head against any track and get a full verdict with a confidence score built on real audio analysis.
          </p>

          <a
            href="#"
            className="inline-flex items-center justify-center font-semibold text-sm uppercase tracking-wider px-8 py-4 rounded-xl bg-gradient-to-br from-[#95fe7c] to-[#5fdf49] text-[#060913] shadow-[0_0_24px_rgba(149,254,124,0.3)] hover:shadow-[0_0_36px_rgba(149,254,124,0.5)] hover:-translate-y-0.5 transition-all duration-200"
          >
            Get your track judged
          </a>
        </div>

        {/* Right 3D Character Stage */}
        <div
          ref={containerRef}
          className="relative w-full h-[520px] bg-[radial-gradient(circle_at_50%_60%,rgba(149,254,124,0.12)_0%,rgba(126,193,251,0.04)_40%,rgba(6,9,19,0.95)_80%)] flex items-center justify-center overflow-hidden"
        >
          {/* Status Badge */}
          <div className="absolute top-6 right-6 z-10 inline-flex items-center gap-2 font-mono text-xs font-bold text-[#95fe7c] bg-[#0a0f1c]/80 border border-[#95fe7c]/40 px-3.5 py-1.5 rounded-full backdrop-blur-md">
            <span className="w-1.5 h-1.5 rounded-full bg-[#95fe7c] shadow-[0_0_8px_#95fe7c]" />
            3D INTERACTIVE · DRAG TO ROTATE
          </div>

          {/* Google model-viewer element */}
          {React.createElement("model-viewer", {
            src: "./djwavy.glb",
            alt: "DJ Wavy 3D Character",
            "auto-rotate": true,
            "rotation-per-second": "25deg",
            "camera-controls": true,
            "shadow-intensity": "1.5",
            exposure: "1.15",
            "camera-orbit": "0deg 75deg 105%",
            "min-camera-orbit": "auto auto 70%",
            "max-camera-orbit": "auto auto 150%",
            loading: "eager",
            "interaction-prompt": "none",
            style: { width: "100%", height: "100%", outline: "none" },
          })}

          {/* Glow Quote Overlay */}
          <div className="absolute bottom-6 left-6 right-6 z-10 bg-[#0a0f1c]/85 backdrop-blur-md p-6 rounded-2xl border border-[#95fe7c]/30 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
            <p className="font-disp font-bold text-base sm:text-lg text-white m-0">
              "If it's not genius, <span className="text-[#95fe7c]">don't waste my time.</span>"
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
