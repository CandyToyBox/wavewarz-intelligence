"use client";
import React, { useEffect, useState } from "react";
import { GradientWave, WAVEWARZ_GRADIENT_PALETTE } from "@/components/ui/gradient-wave";
import { FluidMouseRipple } from "@/components/ui/fluid-mouse-ripple";

interface HeroSectionProps {
  initialBattlesSettled?: number;
}

export function HeroSection({ initialBattlesSettled = 1561 }: HeroSectionProps) {
  const [battlesCount, setBattlesCount] = useState<number>(initialBattlesSettled);
  const [timeLeft, setTimeLeft] = useState<number>(372);
  const [tugRatio, setTugRatio] = useState<number>(44);
  const [cardTilt, setCardTilt] = useState<{ rx: number; ry: number }>({ rx: 0, ry: 0 });

  // Fetch live stats from wavewarz.info public API
  useEffect(() => {
    async function loadStats() {
      try {
        const res = await fetch("https://wavewarz.info/api/public/stats");
        if (!res.ok) return;
        const data = await res.json();
        if (data?.battles?.total) {
          setBattlesCount(data.battles.total);
        }
      } catch (e) {
        // Fallback gracefully to initial count
      }
    }
    loadStats();
    const interval = setInterval(loadStats, 45000);
    return () => clearInterval(interval);
  }, []);

  // Timer simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 372));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Tug of war simulated movement
  useEffect(() => {
    let dir = 1;
    const tug = setInterval(() => {
      setTugRatio((prev) => {
        let next = prev + dir * (0.4 + Math.random() * 0.8);
        if (next > 56 || next < 38) dir *= -1;
        return next;
      });
    }, 1400);
    return () => clearInterval(tug);
  }, []);

  const formatClock = (seconds: number) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  const ringDashoffset = 452.4 * (1 - timeLeft / 372);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - (rect.left + rect.width / 2);
    const y = e.clientY - (rect.top + rect.height / 2);
    setCardTilt({
      rx: (-y / rect.height) * 8,
      ry: (x / rect.width) * 8,
    });
  };

  const handleMouseLeave = () => {
    setCardTilt({ rx: 0, ry: 0 });
  };

  return (
    <div
      className="relative w-full overflow-hidden bg-radial from-[#7ec1fb]/[0.06] to-transparent py-16 lg:py-24"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {/* WebGL Gradient Wave with WaveWarZ Cyber Palette */}
      <GradientWave
        colors={WAVEWARZ_GRADIENT_PALETTE}
        noiseSpeed={0.000008}
        noiseFrequency={[0.00012, 0.00035]}
        deform={{ incline: 0.45, noiseAmp: 260, noiseFlow: 4.2 }}
      />

      {/* Lush Fluid Cursor Ripple Canvas */}
      <FluidMouseRipple />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Badges */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div className="inline-flex items-center gap-3 font-mono text-xs sm:text-sm font-bold tracking-widest text-[#95fe7c] border border-[#95fe7c]/40 rounded-full px-5 py-2 bg-[#95fe7c]/[0.07] backdrop-blur-md shadow-[0_0_30px_rgba(149,254,124,0.2)]">
            <span className="w-2 h-2 rounded-full bg-[#95fe7c] animate-ping" />
            LIVE QUICK BATTLEZ
          </div>
          <div className="flex items-center gap-6 font-mono text-xs sm:text-sm text-[#8b97ab]">
            <span>
              <b className="text-[#95fe7c]">SKIP QUEUE:</b> 0.02 SOL
            </span>
            <span>
              <b className="text-[#daecfd]">{battlesCount.toLocaleString()}</b> BATTLES SETTLED ONCHAIN
            </span>
          </div>
        </div>

        {/* 3D Interactive Battle Arena */}
        <div
          className="relative grid grid-cols-1 lg:grid-cols-[1fr_340px_1fr] gap-8 items-center bg-[#0a0f1c]/70 backdrop-blur-2xl border border-[#7ec1fb]/20 rounded-3xl p-8 lg:p-12 shadow-[0_40px_120px_rgba(0,0,0,0.75)] transition-transform duration-150 ease-out"
          style={{
            transform: `perspective(1200px) rotateX(${cardTilt.rx.toFixed(2)}deg) rotateY(${cardTilt.ry.toFixed(2)}deg)`,
          }}
        >
          {/* Side A */}
          <div className="flex flex-col gap-5 items-start">
            <div className="relative w-full max-w-[300px] aspect-square rounded-2xl overflow-hidden border-2 border-[#7ec1fb]/30 shadow-[-16px_16px_50px_rgba(0,0,0,0.6)] group hover:scale-[1.03] transition-all duration-500">
              <span className="absolute top-4 left-4 z-10 font-mono text-xs font-bold tracking-wider bg-[#0a0f1c]/80 backdrop-blur-sm border border-[#7ec1fb] text-[#7ec1fb] px-3 py-1 rounded-md">
                SIDE A
              </span>
              <img
                src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=800&auto=format&fit=crop"
                alt="Artwork A"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 h-16 flex items-end gap-1 px-4 pb-3 bg-gradient-to-t from-[#060913]/90 to-transparent">
                {[40, 75, 55, 90, 60, 85, 45, 95, 70].map((h, i) => (
                  <span
                    key={i}
                    className="flex-1 bg-[#7ec1fb] rounded-t-sm animate-pulse"
                    style={{ height: `${h}%`, animationDuration: `${0.6 + (i % 3) * 0.3}s` }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="inline-flex items-center gap-2 font-mono text-xs tracking-wider text-[#7ec1fb] bg-[#7ec1fb]/10 px-3 py-1 rounded-md mb-2">
                &#9836; NOW PLAYING · 1:24 / 6:23
              </div>
              <h2 className="font-disp font-bold text-2xl lg:text-3xl text-white uppercase tracking-tight">
                12 Days of Xmas
              </h2>
              <p className="text-sm text-[#8b97ab]">
                by <b className="text-[#7ec1fb]">@Stormbourne</b>
              </p>
            </div>
          </div>

          {/* Center VS & Pool Dynamics */}
          <div className="flex flex-col items-center text-center gap-6">
            <div className="relative w-36 h-36">
              <svg className="w-full h-full -rotate-90 drop-shadow-[0_0_15px_rgba(149,254,124,0.3)]" viewBox="0 0 160 160">
                <circle
                  cx="80"
                  cy="80"
                  r="72"
                  fill="none"
                  stroke="rgba(255,255,255,0.06)"
                  strokeWidth="8"
                />
                <circle
                  cx="80"
                  cy="80"
                  r="72"
                  fill="none"
                  stroke="#95fe7c"
                  strokeWidth="8"
                  strokeDasharray="452.4"
                  strokeDashoffset={ringDashoffset}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-linear"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-disp text-3xl font-bold text-white tracking-tight">
                  {formatClock(timeLeft)}
                </span>
                <span className="font-mono text-[10px] tracking-widest text-[#8b97ab] mt-0.5">
                  REMAINING
                </span>
              </div>
            </div>

            <div className="font-disp font-extrabold text-2xl text-white tracking-wide">VS</div>

            {/* Dynamic Tug of War */}
            <div className="w-full max-w-[260px]">
              <div className="flex justify-between font-mono text-xs font-semibold mb-2">
                <span className="text-[#7ec1fb]">0.42 SOL</span>
                <span className="text-[#95fe7c]">0.53 SOL</span>
              </div>
              <div className="h-3 w-full bg-[#060913] rounded-full overflow-hidden flex border border-[#7ec1fb]/20">
                <div
                  className="bg-gradient-to-r from-[#38bdf8] to-[#7ec1fb] transition-all duration-1000"
                  style={{ width: `${tugRatio}%` }}
                />
                <div className="flex-1 bg-gradient-to-r from-[#95fe7c] to-[#5fdf49]" />
              </div>
            </div>

            <a
              href="#"
              className="inline-flex items-center justify-center font-semibold text-sm uppercase tracking-wider px-8 py-3.5 rounded-xl bg-gradient-to-br from-[#95fe7c] to-[#5fdf49] text-[#060913] shadow-[0_0_24px_rgba(149,254,124,0.3)] hover:shadow-[0_0_36px_rgba(149,254,124,0.5)] hover:-translate-y-0.5 transition-all duration-200"
            >
              Jump into Battle
            </a>
          </div>

          {/* Side B */}
          <div className="flex flex-col gap-5 items-end text-right">
            <div className="relative w-full max-w-[300px] aspect-square rounded-2xl overflow-hidden border-2 border-[#95fe7c]/30 shadow-[16px_16px_50px_rgba(0,0,0,0.6)] group hover:scale-[1.03] transition-all duration-500">
              <span className="absolute top-4 right-4 z-10 font-mono text-xs font-bold tracking-wider bg-[#0a0f1c]/80 backdrop-blur-sm border border-[#95fe7c] text-[#95fe7c] px-3 py-1 rounded-md">
                SIDE B
              </span>
              <img
                src="https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=800&auto=format&fit=crop"
                alt="Artwork B"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="inline-flex items-center gap-2 font-mono text-xs tracking-wider text-[#8b97ab] bg-white/[0.05] px-3 py-1 rounded-md mb-2">
                UP NEXT
              </div>
              <h2 className="font-disp font-bold text-2xl lg:text-3xl text-white uppercase tracking-tight">
                1. My Lamb
              </h2>
              <p className="text-sm text-[#8b97ab]">
                by <b className="text-[#95fe7c]">@KateMurphy90</b>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
