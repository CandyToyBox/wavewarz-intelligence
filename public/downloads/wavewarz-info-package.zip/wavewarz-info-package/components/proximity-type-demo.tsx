import ProximityType from "@/components/ui/proximity-type";

export default function ProximityTypeDemo() {
  return (
    <div className="flex min-h-[420px] w-full items-center justify-center bg-background px-8">
      <ProximityType
        text="Gravity has a typeface."
        as="h1"
        radius={180}
        weightRange={[340, 900]}
        className="text-foreground"
      />
    </div>
  );
}
