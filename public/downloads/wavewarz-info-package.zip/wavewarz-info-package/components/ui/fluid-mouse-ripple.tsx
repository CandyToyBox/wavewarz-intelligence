"use client";
import React, { useEffect, useRef } from "react";

interface Ripple {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  alpha: number;
  color: string;
  speed: number;
}

export function FluidMouseRipple() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    const ripples: Ripple[] = [];
    let lastX = 0;
    let lastY = 0;
    let lastTime = 0;

    const colors = [
      "rgba(149, 254, 124, 0.4)", // Neon green
      "rgba(126, 193, 251, 0.4)", // Cyber blue
      "rgba(56, 189, 248, 0.35)", // Sky cyan
    ];

    function resize() {
      if (!canvas) return;
      canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      canvas.height = canvas.parentElement?.clientHeight || window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      const now = performance.now();
      if (now - lastTime < 35) return; // throttle emission
      lastTime = now;

      const rect = canvas.getBoundingClientRect();
      const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
      const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;

      const x = clientX - rect.left;
      const y = clientY - rect.top;

      const dist = Math.hypot(x - lastX, y - lastY);
      lastX = x;
      lastY = y;

      const pickedColor = colors[Math.floor(Math.random() * colors.length)];
      ripples.push({
        x,
        y,
        radius: 6,
        maxRadius: Math.min(140, Math.max(50, dist * 3.5)),
        alpha: 0.7,
        color: pickedColor,
        speed: 2.2 + Math.min(dist * 0.05, 3),
      });

      if (ripples.length > 40) ripples.shift();
    };

    window.addEventListener("mousemove", onPointerMove);

    function loop() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = ripples.length - 1; i >= 0; i--) {
        const r = ripples[i];
        r.radius += r.speed;
        r.alpha -= 0.014;

        if (r.alpha <= 0 || r.radius >= r.maxRadius) {
          ripples.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.beginPath();
        ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
        ctx.strokeStyle = r.color.replace(/[\d\.]+\)$/, `${r.alpha})`);
        ctx.lineWidth = 1.8;
        ctx.shadowColor = r.color;
        ctx.shadowBlur = 12;
        ctx.stroke();

        // Inner harmonic echo wave
        if (r.radius > 20) {
          ctx.beginPath();
          ctx.arc(r.x, r.y, r.radius * 0.65, 0, Math.PI * 2);
          ctx.strokeStyle = r.color.replace(/[\d\.]+\)$/, `${r.alpha * 0.45})`);
          ctx.lineWidth = 1.0;
          ctx.stroke();
        }
        ctx.restore();
      }

      animId = requestAnimationFrame(loop);
    }
    loop();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onPointerMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 z-0 pointer-events-none w-full h-full mix-blend-screen"
    />
  );
}
