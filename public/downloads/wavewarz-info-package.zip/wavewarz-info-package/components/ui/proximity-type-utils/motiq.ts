import * as React from "react";

/**
 * useReducedMotion — Hook to detect whether the user has requested reduced motion
 * via system accessibility preferences (prefers-reduced-motion: reduce).
 */
export function useReducedMotion(): boolean {
  const [matches, setMatches] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mql = window.matchMedia("(prefers-reduced-motion: reduce)");
    setMatches(mql.matches);

    const onChange = (e: MediaQueryListEvent) => setMatches(e.matches);
    mql.addEventListener("change", onChange);
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return matches;
}

/**
 * useVisibilityPause — Hook that uses IntersectionObserver to detect when a target
 * element is in viewport, pausing intense rAF animation loops when scrolled away.
 */
export function useVisibilityPause(
  ref: React.RefObject<HTMLElement | null>,
  options: IntersectionObserverInit = { threshold: 0.12 }
): boolean {
  const [isVisible, setIsVisible] = React.useState(true);

  React.useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") return;

    const observer = new IntersectionObserver(([entry]) => {
      setIsVisible(entry.isIntersecting);
    }, options);

    observer.observe(el);
    return () => observer.disconnect();
  }, [ref, options.threshold]);

  return isVisible;
}
