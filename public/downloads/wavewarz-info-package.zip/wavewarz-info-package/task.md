# Tasks
- [x] Update typography and global styles (swap Rajdhani for a more fitting angular/modern font like Orbitron or Chakra Petch)
- [x] Implement scroll-driven animations for "How it works" steps
- [x] Refine the "Where the money goes" section (Data Visualization)
- [x] Clean up and polish the Hero section (Live Arena)
- [x] Refine DJ Wavy section to be more prominent
